---
sidebar_position: 1
---

# How does it work?

Log in to your Incentive Reward Account at https://incentive.minima.global/

** Click the 'Share' button located next to your ‘Invite Link’, which will copy a registration link to your clipboard
Share your link with your friends! It will take them straight to the Incentive Program registration page, where your invite code will already be in place. **
