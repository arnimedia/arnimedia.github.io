---
sidebar_position: 2
---

# How long will this program run?

Until the Minima Token Generation Event

