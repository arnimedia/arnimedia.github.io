---
sidebar_position: 5
---

# That's it?

Yes! Simple as that. You will continue to earn your Invite Bonus Rewards right up until the Token Generation Event - all you need to do is share your code and make sure the people you invite, sign up to the Incentive Program using your Invite Link.

The more people you get to sign up using your code, the better for everyone! After all, the greater the node count, the greater the security of the network and the greater the rewards.
Don’t be tempted to cut corners though! It is important to remember that the Incentive Reward Program #1 rule is one account per human, we don’t want centralization of any kind. Anyone found to be running multiple accounts will lose all their rewards.


