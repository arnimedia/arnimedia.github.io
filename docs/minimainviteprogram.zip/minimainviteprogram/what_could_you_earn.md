---
sidebar_position: 4
---

# What Could You Earn?

For every day a person you invite runs a node, you will earn 0.1 Minima.
So if we assume that each of your invited people run their nodes for a 100 day period, you would earn:

- **5 People Invited**  = 50 Minima
- **10 People Invited** = 100 Minima
- **15 People Invited** = 150 Minima
- **20 People Invited** =200 Minima

